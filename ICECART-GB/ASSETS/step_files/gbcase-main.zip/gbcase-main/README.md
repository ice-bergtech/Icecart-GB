# gbcase
3D-printable case for homebrew GameBoy cartridges

Couldn't find any open-source one, only hundreds of closed-sources shitty ones. So I wasted an hour and a half reverse-engineering an existing cartridge and making this.

Have fun kids.

cheerschelsea486mhzxoxoxoxoxoxo
